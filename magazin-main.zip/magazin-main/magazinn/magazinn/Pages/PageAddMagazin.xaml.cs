﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Classes;

namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddMagazin.xaml
    /// </summary>
    public partial class PageAddMagazin : Page
    {
        private Products _currentperson = new Products();
        public PageAddMagazin(Products selectedMagazin)
        {
            InitializeComponent();
            if (selectedMagazin != null)
                _currentperson = selectedMagazin;
            DataContext = _currentperson;
            productcategory.ItemsSource = MagazinEntities.GetContext().Category.ToList();
            productcategory.SelectedValuePath = "IDcategory";
            productcategory.DisplayMemberPath = "ProductCategory";
            companyname.ItemsSource = MagazinEntities.GetContext().Company.ToList();
            companyname.SelectedValuePath = "IDcompany";
            companyname.DisplayMemberPath = "CompanyName";
        }
        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.Product))
                error.AppendLine("Укажите название товара");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentperson.ItemNumber)))
                error.AppendLine("Укажите артикул товара");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentperson.Price)))
                error.AppendLine("Укажите цену");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentperson.Quantity)))
                error.AppendLine("Укажите количество");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentperson.Measurement)))
                error.AppendLine("Укажите ед.измерения");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentperson.Discount)))
                error.AppendLine("Укажите скидку");
            if (string.IsNullOrWhiteSpace(_currentperson.IDcategory.ToString()))
                error.AppendLine("Укажите номер категории");
            if (string.IsNullOrWhiteSpace(_currentperson.IDcompany.ToString()))
                error.AppendLine("Укажите компанию");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDproducts == 0)
                MagazinEntities.GetContext().Products.Add(_currentperson);//Добавить в контекст
            try
            {

                MagazinEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
