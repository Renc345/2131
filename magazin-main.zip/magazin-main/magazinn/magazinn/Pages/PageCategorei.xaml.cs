﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Pages;
using magazinn.Classes;

namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCategorei.xaml
    /// </summary>
    public partial class PageCategorei : Page
    {
        public PageCategorei()
        {
            InitializeComponent();
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование пользователей
        {
            ClassFrame.frmObj.Navigate(new PageAddCategorei((sender as Button).DataContext as Category));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление пользователей
        {
            ClassFrame.frmObj.Navigate(new PageAddCategorei(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<Category>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MagazinEntities.GetContext().Category.RemoveRange(personForRemoving);
                    MagazinEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = MagazinEntities.GetContext().Category.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                MagazinEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = MagazinEntities.GetContext().Category.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Category.ToList();
        }

        private void CmbFiltrGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrGroup.SelectedValue);
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.Where(x => x.IDcompany == id).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Category.OrderBy(x => x.ProductCategory).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Category.OrderByDescending(x => x.ProductCategory).ToList();
        }



        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Category.Where(x => x.ProductCategory.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }


        //private void BtnToList_Click(object sender, RoutedEventArgs e)
        //{
        //    ClassFrame.frmObj.Navigate(new PageListStudent());
        //}
    }
}

